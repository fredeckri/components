let Tape = function() {

    /*atributos avançados*/
    this.nomeativo = this.nomeativo;


    this.tempo = this.tempo;
    this.bigplayercompra = new array();
    this.bigplayervenda = new array();
    this.blef = this.blef;
    /*atributos avançados*/

    /*atributos basicos*/
    this.ordemcompra = this.ordemcompra;
    this.ordemvenda = this.ordemvenda;
    this.quantidade = this.quantidade;
    /*atributos basicos*/

    //metodos
    this.curvadebezierspread = function() {
        //    metodo calculo compra atual vs venda atual dinamico
    }

    this.curvadebezierliquidez = function() {
        //    metodo calculo compra atual vs venda atual dinamico vs liquidez mediana
    }

    //metodos
    this.mediamovel = function() {
            //    metodo calculo mediamovel
        }
        //metodos
    this.liquidezvariavel = function() {
            //    metodo calculo liquidezvariavel
        }
        //metodos
    this.covariancialiquidez = function() {
            //    metodo calculo covarianciavsliquidez
        }
        //metodos
    this.covanrianciaspread = function() {
            //    metodo calculo covarianciaspread
        }
        //metodos
    this.liquidez = function() {
        //    metodo calculo liquidez volume vs transacoes
    }


}