let Tags = function() {

    this._nome = this._nome;
    this._conteudo = this._conteudo;
    this._nome_classe = this._nome_classe;
    this._pai = this._pai;
    this._classe = "class";
    this._id = this._id;
    this._tipos = this._tipos;

    this._attributos = function() {
        let elem = document.querySelector("#" + this._nome_classe);

        //if (elem !== null)
        button.setAttribute(this._tipos, "defaut");


    }

    this._montatag = function() {
        let ele = document.createElement(this._nome);
        //let tag = document.getElementsByTagName(this._nome);
        ele.setAttribute(this._tipos, "defaut");
        let att = document.createAttribute("class");
        att.value = this._nome_classe;
        ele.setAttributeNode(att);

        ele.textContent = this._conteudo;
        let x = document.querySelector("#" + this._pai);
        if (this._pai !== null && this._pai !== 'undefined' && x !== null)
            document.getElementById(this._pai).appendChild(ele);
        else {
            console.log("Não existe esse pai será criado na body_main se existir!");
            x = document.querySelector("#body_main");
            if (x !== null)
                document.getElementById("body_main").appendChild(ele);
        }
    }


}