function criap() {
    let span = document.getElementById("textonovo").value;
    document.getElementById("span_conteudo").innerHTML = span;



}

function getInnerText() {
    alert(document.getElementById("teste").innerText)
}

function getHTML() {
    alert(document.getElementById("teste").innerHTML)
}

function getTextContent() {
    alert(document.getElementById("teste").textContent)
}