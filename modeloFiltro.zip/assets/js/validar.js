


export const validarInput = input => {
    alert(input.dataset.data);
  };