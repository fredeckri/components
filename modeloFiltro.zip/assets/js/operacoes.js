//operações básicas com duas variaveis 
function ab() {
    var a = 10;
    var b = 20;

    var resultado = a + b;
    document.write("<p> O valor de a + b duas variaveis de ambiente</p> ");
    document.write("<p>a soma de a +b é :" + resultado + "</p>");



    var c = '10';
    var d = '20';
    resultado = c + d;

    document.write("<p> O valor de c + d duas variaveis de ambiente concatenadas</p> ");
    document.write("<p>a soma de c + b  em concatenação é :" + resultado + "</p>");
    document.write("<p> O javascript entende e recebe váriavéis com o string tem duas formas de<br>" +
        "converter seus valores o *parseint*(variavel) de string para número *tostring()* <br>");
}

function escola() {

    document.write("<p> Nota mínima para aprovação é 7 e frequência mínima é 80%. </p> ");
    document.write("<p> Aluno Genivaldo tem nota 7.5</p>");
    document.write("<p> Aluno Genivaldo tem frequência de 79%</p>");
}

function veraluno(nt, freq) {
    const nota = 7;
    const frequencia = 80;

    if (nt >= nota && freq >= frequencia) {
        document.write("<div class='aluno'><h2> Nota:" + nt + "<br>Aprovado </h2>")
        document.write("<h2> Frequência:" + freq + "<br>Aprovado </h2></div>")
    } else {

        document.write("<div class='aluno'><h3> Nota:" + nt + "<br>Reprovado </h3>")
        document.write("<h3> Frequência:" + freq + "<br>Reprovado</h3></div>")
    }
}

function idade() {

    document.write("<p> 0 e menor que 15 - Criança. </p> ");
    document.write("<p> 15 e menor que 30- Adulto.  </p>");
    document.write("<p> 30 e menor que 60- Adulto.</p>");
    document.write("<p>Idade maior ou igual a 60 - Idoso</p>");
    document.write("<button onclick='recidad()'> Digite sua idade</button>");

}

function recidade(idade) {
    if (idade > 0 && idade <= 15)
        alert("você é uma criança");
    if (idade > 15 && idade <= 30)
        alert("você é um Adulto");
    if (idade > 30 && idade < 60)
        alert("você é um Adulto");
    if (idade >= 60)
        alert("você é um Idoso");
}

function suit() {
    document.write("<p>Função Switch</p>");
    document.write("<p> Gosta de qual matéria? </p> ");
    document.write("<p> 01-Matemática</p>");
    document.write("<p> 02-Português");
    document.write("<p> 03-Química</p>");
    document.write("<button onclick='recmateria()'> Digite sua preferência</button>");

}

function recmateri(mater) {
    var opcao = parseInt(mater); //variavel.toString(); conversao para string

    switch (opcao) {
        case 1:
            {
                alert("GOSTO DE Matemática");
                break;
            }
        case 2:
            {
                alert("GOSTO DE Portugûes");
                break;
            }
        case 3:
            {
                alert("GOSTO DE Química");
                break;
            }
        default:
            {
                alert("GOSTO DE Estudar Não!");
                break;
            }

    }



}


function opmatematicos() {
    document.write("<p>Operadores matemáticos </p>");
    var a1 = 100;
    var a2 = 20;

    document.write("<p>a1=100 a2=20 </p>");
    document.write("<p> Adição (+)" + (a1 + a2) + "</p>");
    document.write("<p> Subtração (-)" + (a1 - a2) + "</p>");
    document.write("<p> Multiplicação (*)" + (a1 * a2) + "</p>");
    document.write("<p> Divisão (/)" + (a1 / a2) + "</p>");
    document.write("<p> Modulo (%)" + (a1 % a2) + "</p>");
    a1++;
    document.write("<p> a1 Incremento (++)" + (a1) + "</p>");
    --a2;
    document.write("<p> a2 Decremento (--)" + (a2) + "</p>");

}

function opmatmais01() {

    document.write("<p>Operadores Matemáticos Continuação </p>");
    var a1 = 100;
    var a2 = 20;
    var ola = 'Olá '
    document.write("<p>a1=100 a2=20 </p>");
    document.write("<p> variavel = variavel + 5</p>");
    a1 += 5;
    document.write("<p> variavel +=5 =" + a1);
    document.write("<p> variavel = variavel - 5</p>");
    a1 -= 5;
    document.write("<p> variavel /=5 =" + a1);
    document.write("<p> variavel = variavel / 5</p>");
    a1 /= 5;
    document.write("<p> variavel +=5 =" + a1);
    document.write("<p> variavel = variavel * 5</p>");
    a1 *= 5;
    document.write("<p> variavel *=5 =" + a1);
    document.write("<p> variavel = variavel % 5</p>");
    a1 %= 5;
    document.write("<p> variavel %=5 =" + a1);
    document.write("<p> var+='novastring' Também tem concatenão com strings: ");
    ola += 'Frederick';
    document.write(ola + "</p>");

}

function calculaarea(lar, comprimento) {
    var area = lar * comprimento;
    return area
}


/*
function soma(x,y){
 y = y===undefined ? 0 :y 
 // mesma coisa que dizer que se b for do tipo não definido return 0 senão b
    return x+y;
}

console.log(soma(5,5));
console.log(soma(5,5,10,51)); /javascript desconsidera parâmentros adicionais
*/
//funcoes void não dao return
//funcoes retorno retornam um valor

/*

var filme = "Batman vs superman";

if (true) {
document.write(filme);
}
function aer() {
    document.write();
}    

aer();
escopo
variaveis em escopo global são acessadas por todo script
variaveis em bloco sofrem elevação e tornam-se globais
variaveis em funcões não são acessiveis globalmente só na funcao
    */