function imprimirhora() {
    var horadeagora = new Data();
    horadeagora._data = new Date();
    document.getElementById("hora").textContent = horadeagora._formatohora();
    document.getElementById("hora").textContent = document.getElementById("hora").textContent + " - " + horadeagora._saudacao();

    setTimeout("imprimirhora()", 1000);
}

function imprimedata() {
    let datagora = new Data();
    datagora._data = new Date();

    document.getElementById("data").textContent = datagora._imprimedata();

}