class Formulario {

    constructor (){
        this._formName;
        this._method;
        this._classCampo=[];
        this._methods()=[];
        this._objCampo={};
        this._campo=[];
        
    }

    initialize(){}


    enviar (){ alert('Formulário enviado com sucesso!') }

    get FormName(){ return this._formName; }
    set FormName(value){ this._formName=value; }

    get Method(){ return this._method; }
    set Method(value){ this._method=value; }


    criaCampo(valueN,valueC,valueI,valueV,valueT){

        this._objCampo =
        {
        name:this._nameCampo,
        class:this._classCampo,
        id:this._id,
        value:this._value,
        type:this._type,
        max:this._max,
        min:this._min,
        required:this._trueorfalse,
        method:this._methods()
        }
        return this._objCampo;
    }

    get Campo(){ return this._campo; }
    set Campo(valueN,valueC,valueI,valueV,valueT)
    {
        return this._campo.push(criaCampo(valueN,valueC,valueI,valueV,valueT)); 
        
    } // array de campos
    

}